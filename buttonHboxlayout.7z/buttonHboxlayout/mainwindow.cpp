#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ShowMenu = new QMenu(this);
    setContextMenuPolicy(Qt::CustomContextMenu);

    InsertTraceWindow = ShowMenu->addAction("InSert Trace Window");
    InsertDataWindow = ShowMenu->addAction("InSert Data Window");
    InsertLoggingWindow = ShowMenu->addAction("InSert Logging Window");
    Remove = ShowMenu->addAction("Remove");

    connect(this,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(contextMenuRequested(QPoint)));

    Button_1 = new QPushButton("One");
    Button_1->setFixedHeight(50);
    Button_1->setFixedWidth(70);
    H_layout = new QHBoxLayout(this);
    H_layout->addWidget(Button_1);

    QPushButton *button2 = new QPushButton("Trace");
    button2->setFixedHeight(50);
    button2->setFixedWidth(70);
    QPushButton *button3 = new QPushButton("Data");
    button3->setFixedHeight(50);
    button3->setFixedWidth(70);
    QPushButton *button4 = new QPushButton("Logging");
    button4->setFixedHeight(50);
    button4->setFixedWidth(70);

    V_layout = new QVBoxLayout(this);
    V_layout->addWidget(button2);
    V_layout->addWidget(button3);
    V_layout->addWidget(button4);

    ui->widget->setLayout(V_layout);

    ui->widget_button_1->setLayout(H_layout);

    connect(InsertTraceWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonTrace()));
    connect(InsertDataWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonData()));
    connect(InsertLoggingWindow,SIGNAL(triggered()),this,SLOT(ClickInsertButtonLog()));

}

MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::contextMenuRequested(const QPoint& point)
{
    ShowMenu->popup(mapToGlobal(point));
}

void MainWindow::ClickInsertButtonTrace()
{
    static int i =0;
    button[i] = new QPushButton(tr("Trace %1").arg(i+1));
    button[i]->setFixedHeight(50);
    button[i]->setFixedWidth(70);
    //layout->addWidget(button[i]);
    V_layout->addWidget(button[i]);
    ui->widget->setLayout(V_layout);
    qDebug() << button[i]->cursor().pos();
    qDebug() << button[i]->mapFromGlobal(button[i]->cursor().pos());
    i++;
}

void MainWindow::ClickInsertButtonData()
{
    static int i =0;
    button[i] = new QPushButton(tr("Data %1").arg(i+1));
    button[i]->setFixedHeight(50);
    button[i]->setFixedWidth(70);
    //layout->addWidget(button[i]);
    V_layout->addWidget(button[i]);
    ui->widget->setLayout(V_layout);
    qDebug() <<
    i++;
}

void MainWindow::ClickInsertButtonLog()
{
    static int i =0;
    button[i] = new QPushButton(tr("Logging %1").arg(i+1));
    button[i]->setFixedHeight(50);
    button[i]->setFixedWidth(70);
    //layout->addWidget(button[i]);
    V_layout->addWidget(button[i]);
    ui->widget->setLayout(V_layout);
    i++;
}
